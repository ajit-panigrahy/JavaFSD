package PracticePoject27;

class Stack {
	private static final int MAX_SIZE = 100;
	private int top;
	private int[] array;

	public Stack() {
		this.top = -1;
		this.array = new int[MAX_SIZE];
	}

	// Function to insert an element into the stack (push)
	public void push(int data) {
		if (top == MAX_SIZE - 1) {
			System.out.println("Stack Overflow. Cannot push element " + data);
			return;
		}
		array[++top] = data;
	}

	// Function to remove an element from the stack (pop)
	public int pop() {
		if (isEmpty()) {
			System.out.println("Stack Underflow. Cannot pop element.");
			return -1; // Return a sentinel value for underflow
		}
		return array[top--];
	}

	// Function to check if the stack is empty
	public boolean isEmpty() {
		return top == -1;
	}

	// Function to display the elements of the stack
	public void display() {
		if (isEmpty()) {
			System.out.println("Stack is empty.");
			return;
		}

		System.out.print("Stack Elements: ");
		for (int i = 0; i <= top; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}
}

public class PracticePoject27 {
	public static void main(String[] args) {
		Stack stack = new Stack();

		// Insert elements into the stack (push)
		System.out.println("Inserting elements into the stack:");
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.push(40);

		// Display the stack
		stack.display();

		// Remove elements from the stack (pop)
		System.out.println("Removing elements from the stack:");
		int popped1 = stack.pop();
		int popped2 = stack.pop();

		// Display the popped elements
		System.out.println("Popped Element 1: " + popped1);
		System.out.println("Popped Element 2: " + popped2);

		// Display the stack after popping elements
		stack.display();
	}
}
