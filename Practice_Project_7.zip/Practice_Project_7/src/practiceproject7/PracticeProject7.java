package practiceproject7;

//Writing a program in Java to verify the implementation of inner classes

class OuterClass {
	private int outerVariable = 10;

	class InnerClass {
		void display() {
			System.out.println("Inner Class - Outer Variable: " + outerVariable);
		}
	}
}

public class PracticeProject7 {
	public static void main(String[] args) {
		OuterClass outerObject = new OuterClass();
		OuterClass.InnerClass inner = outerObject.new InnerClass();
		inner.display();
	}
}
