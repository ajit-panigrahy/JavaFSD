package PracticeProject12;
//Write a program in Java to demonstrate sleep() and wait()

class Thread1 implements Runnable {
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(2000);
				wait();
				System.out.println("3:- " + i);
			} catch (Exception e) {
				System.out.println("3-error");
			}
		}
	}
}

class Thread2 implements Runnable {
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(2000);
				wait();
				System.out.println("4:- " + i);
			} catch (Exception e) {
				System.out.println("4-error");
			}
		}
	}
}

public class PracticeProject12 {

	public static void main(String[] args) {
		Thread1 t1 = new Thread1();
		Thread2 t2 = new Thread2();

		Thread t = new Thread(t1);
		Thread th1 = new Thread(t2);

		t.start();
		th1.start();

	}

}
