package PracticePoject29;

import java.util.InputMismatchException;
import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter size of Array : ");
		int s = sc.nextInt();
		int arr[] = new int[s];
		System.out.println("Enter " + s + " elements");
		for (int i = 0; i < s; i++) {
			try {
				System.out.print("Enter " + i + " element : ");
				arr[i] = sc.nextInt();
			} catch (InputMismatchException ex) {
				System.out.println("Ivalid Input Please Enter A Integer Elemet And Try Again");
				return;
			} catch (Exception ex2) {
				System.out.println("Some Unknown Error Occured Please Try Again");
				return;
			}

		}

		System.out.println("Enter the number you want to found : ");
		int e = sc.nextInt();
		sc.close();
		int in = linearSearch(arr, e);

		if (in == -1) {
			System.out.println("Entered Element " + e + " Not In The Array");
		} else {
			System.out.println("Entered Element " + e + " Found At The Index " + in);
		}

	}

	private static int linearSearch(int[] arr, int e) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == e) {
				return i;
			}
		}
		return -1;
	}

}
