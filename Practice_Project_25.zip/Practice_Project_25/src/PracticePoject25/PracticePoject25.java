package PracticePoject25;

class Node {
	int data;
	Node next;

	public Node(int data) {
		this.data = data;
		this.next = null;
	}
}

class SortedCircularLinkedList {
	Node head;

	// Function to insert a new element into a sorted circular linked list
	public void insert(int data) {
		Node newNode = new Node(data);

		// If the list is empty, make the new node the head and point to itself
		if (head == null) {
			head = newNode;
			head.next = head;
		} else {
			Node current = head;

			// Traverse the list to find the correct position to insert
			do {
				if (data < current.next.data || current.next == head) {
					newNode.next = current.next;
					current.next = newNode;
					break;
				}

				current = current.next;
			} while (current != head);
		}
	}

	// Function to display the circular linked list
	public void display() {
		if (head == null) {
			System.out.println("Circular linked list is empty.");
			return;
		}

		Node current = head;
		do {
			System.out.print(current.data + " ");
			current = current.next;
		} while (current != head);

		System.out.println();
	}
}

public class PracticePoject25 {
	public static void main(String[] args) {
		SortedCircularLinkedList circularList = new SortedCircularLinkedList();

		// Insert elements into the sorted circular linked list
		circularList.insert(2);
		circularList.insert(5);
		circularList.insert(7);
		circularList.insert(10);

		System.out.println("Original Sorted Circular Linked List:");
		circularList.display();

		// Insert a new element into the sorted circular linked list
		int elementToInsert = 13;
		circularList.insert(elementToInsert);

		System.out.println("Sorted Circular Linked List after inserting " + elementToInsert + ":");
		circularList.display();
	}
}
