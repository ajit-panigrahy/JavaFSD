package pp70.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import pp70.entity.Quote;

@Controller
public class MainController {

	@GetMapping("/")
	@ResponseBody
	public String index() {

		RestTemplate restTemplate = new RestTemplate();
		Quote quote = restTemplate.getForObject("https://type.fit/api/quotes",
				Quote.class);

		return quote.toString();
	}
}
