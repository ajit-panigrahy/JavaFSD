package pp68;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeProject68ApplicationTests {

	@Test
	void contextLoads() {
	}

}
