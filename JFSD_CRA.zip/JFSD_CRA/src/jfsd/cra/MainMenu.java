package jfsd.cra;

import java.util.Scanner;

public class MainMenu {

	private static Scanner scanner = new Scanner(System.in);

	public static void displayMainMenu() {
		try {
			do {
				System.out.println("\nOPTIONS:");
				System.out.println("1. MY CAMERA");
				System.out.println("2. RENT A CAMERA");
				System.out.println("3. VIEW ALL CAMERAS");
				System.out.println("4. MY WALLET");
				System.out.println("5. EXIT");
				int choice = scanner.nextInt();

				if (choice >= 1 && choice <= 5) {
					switch (choice) {
					case 1:
						new MyCamera().displayMyCameraMenu();
						break;
					case 2:
						new RentCamera().rentAvaiableCamera();
						break;
					case 3:
						ViewAllCamera.viewCameraList();
						break;
					case 4:
						UserWallet.walletBalance();
						break;
					case 5:
						System.out.println("Thank you sincerely for your kind visit.. :)");
						System.exit(0);
						break;
					default:
						throw new IllegalArgumentException("Unexpected value: " + choice);
					}

					break; // Exit the loop if a valid option is chosen
				} else {
					System.out.println("Invalid option. Please try again.");
				}
			} while (true);

		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		} finally {
			if (scanner != null) {
				scanner.close();
			}
		}
	}
}
