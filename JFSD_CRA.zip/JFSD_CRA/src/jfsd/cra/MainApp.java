package jfsd.cra;

public class MainApp {

	public static void main(String[] args) {

		LoginMenu lm = new LoginMenu();
		lm.displayLoginScreen();

	}

}
