package jfsd.cra;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MyCamera {

	private Scanner scanner = new Scanner(System.in);

	public void displayMyCameraMenu() {
		try {
			do {
				System.out.println("\nOPTIONS:");
				System.out.println("1. Add Camera");
				System.out.println("2. Remove Camera");
				System.out.println("3. View All Cameras");
				System.out.println("4. Previous Menu");

				int choice = scanner.nextInt();

				if (choice >= 1 && choice <= 4) {
					switch (choice) {
					case 1:
						addCamera();
						break;
					case 2:
						removeCamera();
						break;
					case 3:
						viewCameraList();
						break;
					case 4:
						MainMenu.displayMainMenu();
						break;
					default:
						throw new IllegalArgumentException("Unexpected value: " + choice);
					}

					break; // Exit the loop if a valid option is chosen
				} else {
					System.out.println("Invalid option. Please try again.");
				}
			} while (true);

		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Please enter a valid number.");
			scanner.nextLine(); // Consume the invalid input
			displayMyCameraMenu(); // Restart the menu
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		} finally {
			if (scanner != null) {
				scanner.close();
			}
		}
	}

	private void addCamera() {
		try {
			System.out.println("Enter Camera Brand : ");
			String brand = scanner.next();
			System.out.println("Enter Camera Model : ");
			String model = scanner.next();
			System.out.println("Enter Camera Price Per Day : ");
			double price = scanner.nextDouble();

			ArrayList<Camera> cameraListAdd = new AddCamera().setNewCameraList(brand, model, price);
			viewCameraListAdd(cameraListAdd);
			displayMyCameraMenu();
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Please enter a valid number.");
			scanner.nextLine(); // Consume the invalid input
			addCamera(); // Restart the add camera process
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			displayMyCameraMenu();
		}
	}

	private void removeCamera() {
		try {
			System.out.println("Current Camera List");
			viewCameraList();
			System.out.println("Enter Camera ID You Want To Remove ");
			int cameraId = scanner.nextInt();
			ArrayList<Camera> cameraListRemove = new RemoveCamera().setNewCameraList(cameraId);
			viewCameraListRemove(cameraListRemove);
			displayMyCameraMenu();
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Please enter a valid number.");
			scanner.nextLine(); // Consume the invalid input
			removeCamera(); // Restart the remove camera process
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			displayMyCameraMenu();
		}
	}

	private void viewCameraList() {
		try {
			CameraList cameraListContainer = new CameraList();
			ArrayList<Camera> cameraList = cameraListContainer.getCameraList();
			System.out.println("=============================================================================");
			System.out.printf("%-12s%-12s%-16s%-20s%s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
			System.out.println("=============================================================================");

			for (Camera camera : cameraList) {
				System.out.printf("%-12d%-12s%-16s%-20.2f%s%n", camera.getId(), camera.getBrand(), camera.getModel(),
						camera.getPricePerDay(), camera.isAvailable() ? "Available" : "Rented");
			}
			System.out.println("=============================================================================");
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			displayMyCameraMenu();
		}
	}

	private void viewCameraListAdd(ArrayList<Camera> cameraListAdd) {
		try {
			System.out.println("New Camera List");
			System.out.println("=============================================================================");
			System.out.printf("%-12s%-12s%-16s%-20s%s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
			System.out.println("=============================================================================");

			for (Camera camera : cameraListAdd) {
				System.out.printf("%-12d%-12s%-16s%-20.2f%s%n", camera.getId(), camera.getBrand(), camera.getModel(),
						camera.getPricePerDay(), camera.isAvailable() ? "Available" : "Rented");
			}
			System.out.println("=============================================================================");
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			displayMyCameraMenu();
		}
	}

	private void viewCameraListRemove(ArrayList<Camera> cameraListRemove) {
		try {
			System.out.println("New Camera List");
			System.out.println("=============================================================================");
			System.out.printf("%-12s%-12s%-16s%-20s%s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
			System.out.println("=============================================================================");

			for (Camera camera : cameraListRemove) {
				System.out.printf("%-12d%-12s%-16s%-20.2f%s%n", camera.getId(), camera.getBrand(), camera.getModel(),
						camera.getPricePerDay(), camera.isAvailable() ? "Available" : "Rented");
			}
			System.out.println("=============================================================================");
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			displayMyCameraMenu();
		}
	}
}
