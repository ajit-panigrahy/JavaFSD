package jfsd.cra;

public class Users {

	private static String username = "admin";
	private static String password = "admin123";
	private static double walletBalance = 1750.00;

	public static String getUsername() {
		return username;
	}

//	public void setUsername(String username) {
//		this.username = username;
//	}

	public static String getPassword() {
		return password;
	}

//	public void setPassword(String password) {
//		this.password = password;
//	}

	public static double getWalletBalance() {
		return walletBalance;
	}

//	public void setWalletBalance(double walletBalance) {
//		this.walletBalance = walletBalance;
//	}

}
