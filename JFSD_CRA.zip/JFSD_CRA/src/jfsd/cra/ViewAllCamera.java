package jfsd.cra;

import java.util.ArrayList;

public class ViewAllCamera {

	public static void viewCameraList() {
		try {
			CameraList cameraListContainer = new CameraList();
			ArrayList<Camera> cameraList = cameraListContainer.getCameraList();
			System.out.println("=============================================================================");
			System.out.printf("%-12s%-12s%-16s%-20s%s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
			System.out.println("=============================================================================");

			for (Camera camera : cameraList) {
				System.out.printf("%-12d%-12s%-16s%-20.2f%s%n", camera.getId(), camera.getBrand(), camera.getModel(),
						camera.getPricePerDay(), camera.isAvailable() ? "AVAILABLE" : "RENTED");
			}
			System.out.println("=============================================================================");
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		} finally {
			MainMenu.displayMainMenu();
		}
	}
}
