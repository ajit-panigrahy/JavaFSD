package jfsd.cra;

import java.util.ArrayList;
import java.util.List;

public class CameraList {

	private ArrayList<Camera> cameraList = new ArrayList<>();

	public CameraList() {
		// Constructor: Initialize the cameraList and add cameras
		cameraList.add(new Camera(1, "NIKON", "SOMETHING", 100, true));
		cameraList.add(new Camera(2, "GOPRO", "SOMETHING", 2300, true));
		cameraList.add(new Camera(3, "CANON", "SOMETHING", 400, true));
		cameraList.add(new Camera(4, "NIKON", "SOMETHING", 700, false));
		cameraList.add(new Camera(5, "SONY", "SOMETHING", 300, true));
		cameraList.add(new Camera(6, "NIKON", "SOMETHING", 500, true));
		cameraList.add(new Camera(7, "SONY", "SOMETHING", 800, false));
		cameraList.add(new Camera(8, "PANASONIC", "SOMETHING", 1100, false));
		cameraList.add(new Camera(9, "CANON", "SOMETHING", 600, true));
		cameraList.add(new Camera(10, "SONY", "SOMETHING", 1100, false));
		cameraList.add(new Camera(11, "NIKON", "SOMETHING", 100, true));
		cameraList.add(new Camera(12, "GOPRO", "SOMETHING", 2300, true));
		cameraList.add(new Camera(13, "CANON", "SOMETHING", 400, true));
		cameraList.add(new Camera(14, "NIKON", "SOMETHING", 700, false));
		cameraList.add(new Camera(15, "SONY", "SOMETHING", 300, true));
		cameraList.add(new Camera(16, "NIKON", "SOMETHING", 500, true));
		cameraList.add(new Camera(17, "SONY", "SOMETHING", 800, false));
		cameraList.add(new Camera(18, "PANASONIC", "SOMETHING", 1100, false));
		cameraList.add(new Camera(19, "CANON", "SOMETHING", 600, true));
		cameraList.add(new Camera(20, "SONY", "SOMETHING", 1100, false));
		cameraList.add(new Camera(21, "NIKON", "SOMETHING", 100, true));
		cameraList.add(new Camera(22, "GOPRO", "SOMETHING", 2300, true));
		cameraList.add(new Camera(23, "CANON", "SOMETHING", 400, true));
		cameraList.add(new Camera(24, "NIKON", "SOMETHING", 700, false));
		cameraList.add(new Camera(25, "SONY", "SOMETHING", 300, true));
		cameraList.add(new Camera(26, "NIKON", "SOMETHING", 500, true));
		cameraList.add(new Camera(27, "SONY", "SOMETHING", 800, false));
		cameraList.add(new Camera(28, "PANASONIC", "SOMETHING", 1100, false));
		cameraList.add(new Camera(29, "CANON", "SOMETHING", 600, true));
		cameraList.add(new Camera(30, "SONY", "SOMETHING", 1100, false));
	}

	public ArrayList<Camera> getCameraList() {
		return cameraList;
	}

	public void setCameraList(ArrayList<Camera> cameraList) {
		this.cameraList = cameraList;
	}
}
