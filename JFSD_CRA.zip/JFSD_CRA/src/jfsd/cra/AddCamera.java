package jfsd.cra;

import java.util.ArrayList;
import java.util.Scanner;

public class AddCamera {
	private ArrayList<Camera> cameraList = new CameraList().getCameraList();

	public ArrayList<Camera> setNewCameraList(String brand, String model, double price) {
		try (Scanner sc = new Scanner(System.in)) {
			String password = Users.getPassword();
			System.out.println("Enter Your Password : ");
			String pass = sc.nextLine();

			if (password.equals(pass)) {
				int id = cameraList.size() + 1;
				cameraList.add(new Camera(id, brand, model, price, true));
				System.out.println("Camera Added Successfully");
			} else {
				System.out.println("Incorrect Password. Camera Not Added.");
				new MyCamera().displayMyCameraMenu();
			}
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		}
		return cameraList;
	}
}
