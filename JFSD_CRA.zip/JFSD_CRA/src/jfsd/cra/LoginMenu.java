package jfsd.cra;

import java.util.Scanner;

public class LoginMenu {

	private String username;
	private String password;
	private Scanner scanner;

	public LoginMenu() {
		try {
			username = Users.getUsername();
			password = Users.getPassword();
			scanner = new Scanner(System.in);
		} catch (Exception e) {
			System.out.println("An error occurred during initialization: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void displayLoginScreen() {
		try {
			System.out.println("+------------------------------+\n" + "| WELCOME TO CAMERA RENTAL APP |\n"
					+ "+------------------------------+\n");
			System.out.println("PLEASE LOGIN TO CONTINUE");

			// authentication of the user
			do {
				System.out.print(" USERNAME - ");
				String enteredUsername = scanner.nextLine();

				System.out.print(" PASSWORD - ");
				String enteredPassword = scanner.nextLine();

				if (enteredUsername.equals(this.username) && enteredPassword.equalsIgnoreCase(this.password)) {
					MainMenu.displayMainMenu();
					break; // Exit the loop if credentials are valid
				} else {
					System.out.println("Invalid credentials. Please try again.");
				}
			} while (true); // Continue looping until valid credentials are entered

		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		} finally {
			if (scanner != null) {
				scanner.close();
			}
		}
	}
}
