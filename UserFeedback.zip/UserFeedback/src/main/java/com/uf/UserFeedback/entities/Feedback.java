package com.uf.UserFeedback.entities;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "User_Feedback")
public class Feedback {

	@Id
	@GeneratedValue
	@Column(name = "Feedback_Number")
	private int fno;
	@Column(name = "User_Feedback")
	private String feedback;
	@Column(name = "Feedback_Date")
	@DateTimeFormat(pattern = "dd MM yyyy HH:mm:ss")
	private LocalDateTime date;
	public int getFno() {
		return fno;
	}
	public void setFno(int fno) {
		this.fno = fno;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}

}
