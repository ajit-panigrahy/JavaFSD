package com.uf.UserFeedback.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.uf.UserFeedback.entities.Feedback;

public interface FeedbackRepo extends JpaRepository<Feedback, Integer> {

}
