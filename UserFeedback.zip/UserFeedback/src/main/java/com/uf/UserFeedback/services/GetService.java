package com.uf.UserFeedback.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uf.UserFeedback.entities.Feedback;
import com.uf.UserFeedback.repo.FeedbackRepo;

@Service
public class GetService implements Services {

	@Autowired
	private FeedbackRepo fr;

	@Override
	public void addFeedback(Feedback f) {
		fr.save(f);
	}

	@Override
	public List<Feedback> getFeedback() {
		List<Feedback> f = fr.findAll();
		return f;
	}

	@Override
	public boolean deleteFeedback(int fid) {
		if (fr.findById(fid).isEmpty()) {
			fr.deleteById(fid);
			return false;
		}
		return true;
	}

}
