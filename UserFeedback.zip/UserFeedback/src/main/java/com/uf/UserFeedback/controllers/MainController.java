package com.uf.UserFeedback.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.uf.UserFeedback.entities.Feedback;
import com.uf.UserFeedback.services.Services;

@RestController
public class MainController {

	@Autowired
	private Services s;

	@PostMapping("/addfeedback")
	public ResponseEntity<Object> addFeedback(@RequestBody Feedback feedback) {
		s.addFeedback(feedback);
		return new ResponseEntity<Object>(
				"Thank you for your valuable feedback... ", HttpStatus.OK);
	}

	@GetMapping("/getfeedback")
	public ResponseEntity<Object> getFeedback() {
		List<Feedback> f = s.getFeedback();
		if (!f.isEmpty())
			return new ResponseEntity<Object>(f, HttpStatus.OK);
		return new ResponseEntity<Object>(
				"Feedback not found/ is empty. Please try adding your valuable feedbavk",
				HttpStatus.NOT_FOUND);
	}

	@PostMapping("/deletefeedback/{fid}")
	public ResponseEntity<Object> deleteFeedback(@PathVariable int fid) {
		boolean b = s.deleteFeedback(fid);
		if (b==true)
			return new ResponseEntity<Object>("Feedback deleted....",
					HttpStatus.OK);

		return new ResponseEntity<Object>("Feedback not found....",
				HttpStatus.NOT_FOUND);

	}

}
