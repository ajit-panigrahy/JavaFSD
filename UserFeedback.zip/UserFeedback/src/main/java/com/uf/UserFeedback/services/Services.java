package com.uf.UserFeedback.services;

import java.util.List;

import com.uf.UserFeedback.entities.Feedback;

public interface Services {

	public void addFeedback(Feedback f);
	public List<Feedback> getFeedback();
	public boolean deleteFeedback(int fid);

}
