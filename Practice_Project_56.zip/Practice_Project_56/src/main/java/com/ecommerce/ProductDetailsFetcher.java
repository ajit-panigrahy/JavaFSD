package com.ecommerce;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.ecommerce.Color;
import com.ecommerce.EProduct;
import com.ecommerce.Finance;
import com.ecommerce.HibernateUtil;
import com.ecommerce.OS;
import com.ecommerce.ScreenSizes;

public class ProductDetailsFetcher {

	public static void main(String[] args) {
		try {
			SessionFactory factory = HibernateUtil.getSessionFactory();
			List<EProduct> productList = null;
			try (Session session = factory.openSession()) {
				Transaction tx = null;
				tx = session.beginTransaction();
				String query = "FROM EProduct";
				TypedQuery q = session.createQuery(query);
				productList = q.getResultList();
				tx.commit();
				for (EProduct product : productList) {
					System.out.println("ID: " + product.getID() + ", Name: " + product.getName() + ", Price: "
							+ product.getPrice() + ", Date Added: " + product.getDateAdded());

					List<Color> colors = product.getColors();
					System.out.print("Colors: ");
					for (Color color : colors) {
						System.out.print(color.getName() + " ");
					}

					Collection<ScreenSizes> sizes = product.getScreensizes();
					System.out.print(", Screen Sizes: ");
					for (ScreenSizes size : sizes) {
						System.out.print(size.getSize() + " ");
					}

					Set<OS> os = product.getOs();
					System.out.print(", OS: ");
					for (OS operatingSystem : os) {
						System.out.print(operatingSystem.getName() + " ");
					}

					Map<String, Finance> finances = product.getFinance();
					System.out.print(", Finance Options: ");
					if (finances.get("CREDITCARD") != null) {
						Finance creditCardFinance = finances.get("CREDITCARD");
						System.out.print(creditCardFinance.getName() + " ");
					}
					if (finances.get("BANK") != null) {
						Finance bankFinance = finances.get("BANK");
						System.out.print(bankFinance.getName() + " ");
					}

					System.out.println("\n------------------------");
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
