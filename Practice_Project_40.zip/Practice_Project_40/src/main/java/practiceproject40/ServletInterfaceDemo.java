package practiceproject40;
//Write a program to demonstrate a Servlet Filter.

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ServletInterfaceDemo")
public class ServletInterfaceDemo extends HttpServlet {

	@Override
	public void init(ServletConfig config)

			throws ServletException {
		super.init(config);
		System.out.println("Servlet initialized.");
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("ServletContext: " + getServletContext());
		System.out.println("ServletConfig: " + getServletConfig());
		System.out.println("ServletRequest: " + request);
		System.out.println("ServletResponse: " + response);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>Servlet Classes and Interfaces</h2>");
		out.println("ServletContext, ServletConfig, ServletRequest, and ServletResponse objects are available.");
	}

	@Override
	public void destroy() {
		System.out.println("Servlet destroyed.");
	}
}