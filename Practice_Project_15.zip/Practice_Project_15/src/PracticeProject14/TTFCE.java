package PracticeProject14;
////Writing a program in Java to throws, throw, finally, and custom exceptions in Java.

class CustomException extends Exception {
	public CustomException(String message) {
		super(message);
	}
}

class ExceptionDemo {
	public void processInput(int input) throws CustomException {
		if (input < 0) {
			throw new CustomException("Input cannot be negative");
		}
		System.out.println("Processing input: " + input);
	}
}

class ThrowsExample {
	public void throwsExample() throws CustomException {
		ExceptionDemo demo = new ExceptionDemo();

		demo.processInput(10);
		// demo.processInput(-5);
	}
}

class ThrowFinallyExample {
	public void throwFinallyExample() {
		ExceptionDemo demo = new ExceptionDemo();

		try {
			demo.processInput(20);
			// demo.processInput(-8); // This will throw a CustomException
		} catch (CustomException e) {
			System.err.println("Caught CustomException: " + e.getMessage());
		} finally {
			System.out.println("Finally block: This code will always execute.");
		}
	}
}

public class TTFCE {
	public static void main(String[] args) throws CustomException {
		ExceptionDemo ed = new ExceptionDemo();
		ed.processInput(10);
		System.out.println();
		ThrowsExample te = new ThrowsExample();
		te.throwsExample();
		System.out.println();
		ThrowFinallyExample tfe = new ThrowFinallyExample();
		tfe.throwFinallyExample();
	}

}
