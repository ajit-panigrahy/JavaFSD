package PracticeProject14;
//Writing a program in Java to throws, throw, finally, and custom exceptions in Java.

import java.util.Scanner;

class TooYoungException extends RuntimeException {
	TooYoungException(String msg) {
		super(msg);
	}
}

class TooOldException extends RuntimeException {
	TooOldException(String msg) {
		super(msg);
	}
}

public class CustomisedException {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your age : ");

		int age = sc.nextInt();

		if (age < 18) {
			throw new TooYoungException("you're too young and not eligible for this role");
		} else if (age > 60) {
			throw new TooOldException("you're too old and not eligible fo this role");
		} else {
			System.out.println("you're eligible for this role");
		}
		sc.close();
	}

}
