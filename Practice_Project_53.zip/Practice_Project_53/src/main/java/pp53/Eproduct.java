package pp53;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import pp53.products.Product;

public class Eproduct {

	public List<Product> listProducts() {
		Session session = HibernateConfig.getSessionFactory().openSession();
		Transaction tx = null;
		List<Product> products = null;

		try {
			tx = session.beginTransaction();
			String query = "FROM Product";
			Query q = session.createQuery(query);
			products = q.list();
			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return products;
	}
}
