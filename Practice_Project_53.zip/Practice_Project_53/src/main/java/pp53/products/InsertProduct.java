package pp53.products;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import pp53.HibernateConfig;

public class InsertProduct {

	public static void main(String[] args) {

		SessionFactory sf = HibernateConfig.getSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();

		Product p1 = new Product("SAMSUNG S23", 143456);
		Product p2 = new Product("IPHONE 14", 54567);
		Product p3 = new Product("VIVO X90 PRO", 60123);

		session.save(p1);
		session.save(p2);
		session.save(p3);

		t.commit();

		session.clear();
		sf.close();

	}

}
