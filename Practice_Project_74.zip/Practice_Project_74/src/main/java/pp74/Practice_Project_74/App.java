package pp74.Practice_Project_74;

public class App {

	public String greet() {
		return "Hello";
	}

}
