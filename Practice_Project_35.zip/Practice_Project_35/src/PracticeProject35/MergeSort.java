package PracticeProject35;

import java.util.Arrays;

public class MergeSort {

	// Merge two sub-arrays L and M into the array
	void merge(int array[], int p, int q, int r) {
		int n1 = q - p + 1;
		int n2 = r - q;

		int L[] = Arrays.copyOfRange(array, p, p + n1);
		int M[] = Arrays.copyOfRange(array, q + 1, q + 1 + n2);

		int i = 0, j = 0, k = p;

		// Merge the sorted sub-arrays
		while (i < n1 && j < n2) {
			if (L[i] <= M[j]) {
				array[k++] = L[i++];
			} else {
				array[k++] = M[j++];
			}
		}

		// Copy the remaining elements of L[], if there are any
		while (i < n1) {
			array[k++] = L[i++];
		}

		// Copy the remaining elements of M[], if there are any
		while (j < n2) {
			array[k++] = M[j++];
		}
	}

	// Divide the array into two sub-arrays, sort them, and merge them
	void mergeSort(int array[], int left, int right) {
		if (left < right) {
			int mid = (left + right) / 2;

			// Recursive call to each sub-array
			mergeSort(array, left, mid);
			mergeSort(array, mid + 1, right);

			// Merge the sorted sub-arrays
			merge(array, left, mid, right);
		}
	}

	public static void main(String args[]) {
		try {
			// Create an unsorted array
			int[] array = { 6, 5, 12, 10, 9, 1 };

			MergeSort ms = new MergeSort();

			// Call the mergeSort() method
			// Pass arguments: array, first index, and last index
			ms.mergeSort(array, 0, array.length - 1);

			System.out.println("Sorted Array:");
			System.out.println(Arrays.toString(array));
		} catch (Exception e) {
			// Handle any unexpected exceptions in the main block
			System.err.println("An error occurred: " + e.getMessage());
		}
	}
}
