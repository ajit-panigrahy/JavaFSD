package practiceproject38;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

//Configure a servlet in Eclipse IDE.

@WebServlet("/Example")
public class Example extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>Welcome</h2>");
		out.println("Hello " + name + ", welcome :)");
	}

}