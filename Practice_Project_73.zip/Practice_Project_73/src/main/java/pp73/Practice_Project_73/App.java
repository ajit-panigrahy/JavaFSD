package pp73.Practice_Project_73;

public class App {

	public String greet() {
		return "Hello";
	}

}
