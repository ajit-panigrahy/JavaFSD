package PracticeProject18;

//Write a program in Java to demonstrate the uses of classes, objects, and the object-oriented pillars in Java

class BankAccount {
	@SuppressWarnings("unused")
	private String accountNumber;
	@SuppressWarnings("unused")
	private String ownerName;
	protected double balance;

	public BankAccount(String accountNumber, String ownerName) {
		this.accountNumber = accountNumber;
		this.ownerName = ownerName;
		this.balance = 0.0;
	}

	public void deposit(double amount) {
		balance += amount;
		System.out.println("Deposit: $" + amount);
		displayBalance();
	}

	public void withdraw(double amount) {
		if (amount <= balance) {
			balance -= amount;
			System.out.println("Withdrawal: $" + amount);
		} else {
			System.out.println("Insufficient funds for withdrawal.");
		}
		displayBalance();
	}

	public void displayBalance() {
		System.out.println("Current Balance: $" + balance);
	}
}

class SavingsAccount extends BankAccount {
	private double interestRate;

	public SavingsAccount(String accountNumber, String ownerName, double interestRate) {
		super(accountNumber, ownerName);
		this.interestRate = interestRate;
	}

	public void applyInterest() {
		double interestAmount = balance * interestRate / 100;
		deposit(interestAmount);
		System.out.println("Interest applied: $" + interestAmount);
	}
}

class Transaction {
	private String type;
	private double amount;

	public Transaction(String type, double amount) {
		this.type = type;
		this.amount = amount;
	}

	public void execute(BankAccount account) {
		if (type.equals("Deposit")) {
			account.deposit(amount);
		} else if (type.equals("Withdrawal")) {
			account.withdraw(amount);
		}
	}
}

public class PracticeProject18 {
	public static void main(String[] args) {

		BankAccount johnAccount = new BankAccount("123456", "Ajit");
		SavingsAccount janeSavings = new SavingsAccount("789012", "Ajit", 4.5);

		Transaction depositTransaction = new Transaction("Deposit", 1000.0);
		depositTransaction.execute(johnAccount);

		Transaction withdrawalTransaction = new Transaction("Withdrawal", 500.0);
		withdrawalTransaction.execute(johnAccount);

		janeSavings.deposit(2000.0);
		janeSavings.applyInterest();
	}
}
