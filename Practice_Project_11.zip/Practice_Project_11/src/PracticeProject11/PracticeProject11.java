package PracticeProject11;
//Write a program in Java to create a thread by extending the ‘Thread’ class and by implementing the “Runnable” interface

class Thread1 extends Thread {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("1:- " + i);
		}
	}
}

class Thread2 implements Runnable {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("2:- " + i);
		}
	}
}

public class PracticeProject11 {

	public static void main(String[] args) {
		Thread1 t1 = new Thread1();
		t1.start();
		Thread2 t2 = new Thread2();
		Thread t = new Thread(t2);
		t.start();

	}

}
