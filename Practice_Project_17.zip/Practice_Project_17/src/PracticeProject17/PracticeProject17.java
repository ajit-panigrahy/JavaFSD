package PracticeProject17;
//Writing a program in Java to create, read, update, and delete operations on the files in Java.

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class PracticeProject17 {

	public static void main(String[] args) {
		String filePath = "example.txt";

		createFile(filePath);

		readFile(filePath);

		updateFile(filePath, "Updated content");

		readFile(filePath);

		deleteFile(filePath);
	}

	private static void createFile(String filePath) {
		try {
			Path path = Paths.get(filePath);
			String content = "Hello, this is the content of the file.";

			Files.write(path, content.getBytes());
			System.out.println("File created successfully.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void readFile(String filePath) {
		try {
			Path path = Paths.get(filePath);
			List<String> lines = Files.readAllLines(path);

			System.out.println("File content:");
			for (String line : lines) {
				System.out.println(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void updateFile(String filePath, String newContent) {
		try {
			Path path = Paths.get(filePath);

			Files.write(path, newContent.getBytes(), java.nio.file.StandardOpenOption.APPEND);
			System.out.println("File updated successfully.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void deleteFile(String filePath) {
		try {
			Path path = Paths.get(filePath);
			Files.delete(path);
			System.out.println("File deleted successfully.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
