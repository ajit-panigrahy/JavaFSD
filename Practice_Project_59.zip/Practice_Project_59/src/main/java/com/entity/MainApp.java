package com.entity;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class)) {
			EmployeeService employeeService = context.getBean(EmployeeService.class);

			Employee employee = new Employee();
			employee.setName("Aarti Kulkarni");
			employeeService.saveEmployee(employee);

			List<Employee> employees = employeeService.getAllEmployees();
			for (Employee emp : employees) {
				System.out.println("Employee ID: " + emp.getId() + ", Name: " + emp.getName());
			}
		}
	}
}
