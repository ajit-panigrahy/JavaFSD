package com.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class EmployeeService {

	@Autowired
	private SessionFactory sessionFactory;

	public void saveEmployee(Employee employee) {
		getCurrentSession().save(employee);
	}

	public List<Employee> getAllEmployees() {
		return getCurrentSession().createQuery("FROM Employee", Employee.class).getResultList();
	}

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
}
