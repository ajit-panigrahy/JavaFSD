package PracticeProject31;

public class ExponentialSearch {

	// Perform binary search within the given range [start, end]
	private static int binarySearch(int[] arr, int start, int end, int target) {
		while (start <= end) {
			int mid = start + (end - start) / 2;

			if (arr[mid] == target) {
				return mid; // Target found
			} else if (arr[mid] < target) {
				start = mid + 1; // Search in the right half
			} else {
				end = mid - 1; // Search in the left half
			}
		}

		return -1; // Target not found
	}

	// Perform exponential search
	public static int exponentialSearch(int[] arr, int target) {
		int n = arr.length;

		// Check if the target is at the first position
		if (n > 0 && arr[0] == target) {
			return 0;
		}

		// Find the range where the target may be present
		int i = 1;
		while (i < n && arr[i] <= target) {
			i *= 2;
		}

		try {
			// Perform binary search within the identified range
			return binarySearch(arr, i / 2, Math.min(i, n - 1), target);
		} catch (Exception e) {
			// Handle exceptions here (e.g., if the array is not sorted)
			System.err.println("An error occurred: " + e.getMessage());
			return -1;
		}
	}

	public static void main(String[] args) {
		try {
			// Example array (sorted in ascending order)
			int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

			// Target element to search for
			int target = 7;

			// Perform exponential search
			int result = exponentialSearch(array, target);

			// Display the result
			if (result != -1) {
				System.out.println("Element found at index: " + result);
			} else {
				System.out.println("Element not found in the array");
			}
		} catch (Exception e) {
			// Handle any unexpected exceptions in the main block
			System.err.println("An error occurred: " + e.getMessage());
		}
	}
}
