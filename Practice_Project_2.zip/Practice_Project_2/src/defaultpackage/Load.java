package defaultpackage;

class Load {
	void message() {
		System.out.println("This is a message");
	}
}