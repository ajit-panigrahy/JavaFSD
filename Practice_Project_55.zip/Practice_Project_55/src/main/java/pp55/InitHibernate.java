package pp55;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.hibernate.SessionFactory;

@WebServlet("/initHibernate")
public class InitHibernate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		// Initialize Hibernate
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		System.out.println("Hibernate initialized successfully!");
	}
}
