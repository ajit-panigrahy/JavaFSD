package com.ua.UserAuthentication;

import static org.junit.Assert.assertEquals;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class AppTest {
	private App app = new App();
	@ParameterizedTest
	@MethodSource("inputs")
	public void validateUserTest(String u, String p, boolean expected) {
		boolean actual = app.userAuthentication(u, p);
		assertEquals(expected, actual);
	}

	static Stream<Arguments> inputs() {
		return Stream.of(Arguments.of("admin", "admin123", true),
				Arguments.of("ADMIN", "ADMIN123", true),
				Arguments.of("admin", "admin", false),
				Arguments.of("ADMIN123", "ADMIN", false));
	}

}
