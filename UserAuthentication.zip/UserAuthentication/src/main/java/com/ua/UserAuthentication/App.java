package com.ua.UserAuthentication;

public class App {

	public boolean userAuthentication(String username, String password) {

		return username.equalsIgnoreCase("admin")
				&& password.equalsIgnoreCase("admin123");
	}

}
