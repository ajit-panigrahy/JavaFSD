package pp71;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject68Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject68Application.class, args);
		System.out.println("Started...............");
	}

}
