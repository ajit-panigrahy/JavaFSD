package pp71.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pp71.repo.ProductRepository;

@Controller
public class MainController {

	@Autowired
	private ProductRepository repository;

	@GetMapping("/")
	@ResponseBody
	public String index() {

		return "This is running under SSL";
	}

}
