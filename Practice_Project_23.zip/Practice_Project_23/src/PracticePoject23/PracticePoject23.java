package PracticePoject23;

import java.util.Scanner;

public class PracticePoject23 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the number of rows for matrix A: ");
		int rowsA = scanner.nextInt();

		System.out.print("Enter the number of columns for matrix A: ");
		int colsA = scanner.nextInt();

		System.out.print("Enter the number of rows for matrix B: ");
		int rowsB = scanner.nextInt();

		System.out.print("Enter the number of columns for matrix B: ");
		int colsB = scanner.nextInt();

		// Check if matrix multiplication is possible
		if (colsA != rowsB) {
			System.out.println("Matrix multiplication is not possible with the given size.");
		} else {
			int[][] matrixA = new int[rowsA][colsA];
			int[][] matrixB = new int[rowsB][colsB];

			// Input elements of matrix A
			System.out.println("Enter the elements of matrix A:");
			inputMatrixElements(matrixA, scanner);

			// Input elements of matrix B
			System.out.println("Enter the elements of matrix B:");
			inputMatrixElements(matrixB, scanner);

			// Multiply matrices
			int[][] resultMatrix = multiplyMatrices(matrixA, matrixB);

			// Display the result
			System.out.println("Resultant matrix after multiplication:");
			displayMatrix(resultMatrix);
		}

		scanner.close();
	}

	// Function to input elements of a matrix
	private static void inputMatrixElements(int[][] matrix, Scanner scanner) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[0].length; j++) {
				System.out.print("Element at position (" + (i) + ", " + (j) + "): ");
				matrix[i][j] = scanner.nextInt();
			}
		}
	}

	// Function to multiply two matrices
	private static int[][] multiplyMatrices(int[][] matrixA, int[][] matrixB) {
		int rowsA = matrixA.length;
		int colsA = matrixA[0].length;
		int colsB = matrixB[0].length;

		int[][] resultMatrix = new int[rowsA][colsB];

		for (int i = 0; i < rowsA; i++) {
			for (int j = 0; j < colsB; j++) {
				for (int k = 0; k < colsA; k++) {
					resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
				}
			}
		}

		return resultMatrix;
	}

	// Function to display the elements of a matrix
	private static void displayMatrix(int[][] matrix) {
		for (int[] row : matrix) {
			for (int element : row) {
				System.out.print(element + " ");
			}
			System.out.println();
		}
	}
}
