package practiceproject42;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)

			throws ServletException, IOException

	{
		HttpSession session = request.getSession();

		// Check if session is new
		if (session.isNew()) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<h2>Welcome to the session!</h2>");

			// Redirect to the same servlet, appending session ID to URL
			String redirectURL = response.encodeRedirectURL(request.getRequestURI());
			response.sendRedirect(redirectURL);
		} else {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<h2>Welcome back to the session!</h2>");
			out.println("<p>Your session ID is: " + session.getId() + "</p>");
		}
	}
}