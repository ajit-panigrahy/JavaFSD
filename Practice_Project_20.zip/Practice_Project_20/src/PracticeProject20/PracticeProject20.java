package PracticeProject20;
//Write a program in Java to right rotate an array by 5 steps

import java.util.Arrays;

public class PracticeProject20 {
	public static void main(String[] args) {
		int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		int steps = 5;

		System.out.println("Original Array: " + Arrays.toString(array));

		rightRotateArray(array, steps);

		System.out.println("Array after right rotation by " + steps + " steps: " + Arrays.toString(array));
	}

	// Function to right rotate an array by 'steps' steps
	private static void rightRotateArray(int[] arr, int steps) {
		int n = arr.length;

		steps = steps % n;

		reverseArray(arr, 0, n - 1);
		reverseArray(arr, 0, steps - 1);
		reverseArray(arr, steps, n - 1);
	}

	private static void reverseArray(int[] arr, int start, int end) {
		while (start < end) {
			int temp = arr[start];
			arr[start] = arr[end];
			arr[end] = temp;
			start++;
			end--;
		}
	}
}
