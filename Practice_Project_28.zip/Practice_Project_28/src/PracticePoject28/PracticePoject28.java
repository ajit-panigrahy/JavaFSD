package PracticePoject28;

class Queue {
	private static final int MAX_SIZE = 10;
	private int front, rear, size;
	private int[] array;

	public Queue() {
		this.front = this.rear = -1;
		this.size = 0;
		this.array = new int[MAX_SIZE];
	}

	// Function to insert an element into the queue (enqueue)
	public void enqueue(int data) {
		if (rear == MAX_SIZE - 1) {
			System.out.println("Queue Overflow. Cannot enqueue element " + data);
			return;
		}

		if (isEmpty()) {
			front = rear = 0;
		} else {
			rear++;
		}

		array[rear] = data;
		size++;
	}

	// Function to remove an element from the queue (dequeue)
	public int dequeue() {
		if (isEmpty()) {
			System.out.println("Queue Underflow. Cannot dequeue element.");
			return -1; // Return a sentinel value for underflow
		}

		int dequeuedElement = array[front];
		if (front == rear) {
			front = rear = -1;
		} else {
			front++;
		}

		size--;
		return dequeuedElement;
	}

	// Function to check if the queue is empty
	public boolean isEmpty() {
		return front == -1;
	}

	// Function to display the elements of the queue
	public void display() {
		if (isEmpty()) {
			System.out.println("Queue is empty.");
			return;
		}

		System.out.print("Queue Elements: ");
		for (int i = front; i <= rear; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}
}

public class PracticePoject28 {
	public static void main(String[] args) {
		Queue queue = new Queue();

		// Insert elements into the queue (enqueue)
		System.out.println("Inserting elements into the queue:");
		queue.enqueue(10);
		queue.enqueue(20);
		queue.enqueue(30);
		queue.enqueue(40);

		// Display the queue
		queue.display();

		// Remove elements from the queue (dequeue)
		System.out.println("Removing elements from the queue:");
		int dequeued1 = queue.dequeue();
		int dequeued2 = queue.dequeue();

		// Display the dequeued elements
		System.out.println("Dequeued Element 1: " + dequeued1);
		System.out.println("Dequeued Element 2: " + dequeued2);

		// Display the queue after dequeuing elements
		queue.display();
	}
}
