package PracticeProject30;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter size of Array : ");
		int s = sc.nextInt();
		int arr[] = new int[s];
		System.out.println("Enter " + s + " elements");

		for (int i = 0; i < s; i++) {
			try {
				System.out.print("Enter " + i + " element : ");
				arr[i] = sc.nextInt();
			} catch (InputMismatchException ex) {
				System.out.println("Ivalid Input Please Enter A Integer Elemet And Try Again");
				return;
			} catch (Exception ex2) {
				System.out.println("Some Unknown Error Occured Please Try Again");
				return;
			}

		}

		Arrays.sort(arr);

		System.out.println("Enter the number you want to found : ");
		int e = sc.nextInt();

		int in = binarySearch(arr, e);

		sc.close();

		if (in == -1) {
			System.out.println("Entered Element " + e + " Not In The Array");
		} else {
			System.out.println("Entered Element " + e + " Found At The Index " + in);
		}

	}

	private static int binarySearch(int[] arr, int e) {
		int mid = arr[arr.length / 2];

		if (mid > e) {
			for (int i = 0; i < arr.length / 2 - 1; i++) {
				if (arr[i] == e) {
					return i;
				}
			}
		} else if (mid < e) {
			for (int i = arr.length / 2 + 1; i < arr.length; i++) {
				if (arr[i] == e) {
					return i;
				}
			}
		} else if (mid == e) {
			return arr.length / 2;
		}
		return -1;
	}

}
