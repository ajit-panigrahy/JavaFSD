package PracticeProject14;
//Write a program in Java to demonstrate try and catch

public class PracticeProject14 {

	public static void main(String[] args) {

		try {
			System.out.println(10 / 0);
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}

	}
}
