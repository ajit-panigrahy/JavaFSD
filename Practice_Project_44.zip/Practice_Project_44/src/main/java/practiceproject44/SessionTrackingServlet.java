package practiceproject44;
//Write a program to demonstrate Session Tracking using an HTTP Session.

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		Integer counter = (Integer) session.getAttribute("counter");
		if (counter == null) {
			counter = 1;
		} else {
			counter++;
		}

		session.setAttribute("counter", counter);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>You have visited this page " + counter + " times in this session.</h2>");
	}
}