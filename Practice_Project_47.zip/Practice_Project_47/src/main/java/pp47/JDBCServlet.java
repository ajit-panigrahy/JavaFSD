package pp47;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/JDBCServlet")
public class JDBCServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>JDBC Servlet</title></head><body>");

		Connection connection = null;

		try {
			String driver = "com.mysql.cj.jdbc.Driver";// type 4 thin driver
			Class.forName(driver);
			String URL = "jdbc:mysql://localhost:3306/JDBC";
			String username = "root";
			String password = "Aa@@11@@";

			connection = DriverManager.getConnection(URL, username, password);

			out.println("<p> JDBC initialized successfully. </p>");
		} catch (ClassNotFoundException | SQLException e) {
			out.println("<p> Error initializing JDBC: " + e.getMessage() + "</p>");
		} finally {

			try {
				if (connection != null && !connection.isClosed()) {
					connection.close();
					out.println("<p> JDBC connection closed successfully. </p>");
				}
			} catch (SQLException e) {
				out.println("<p> Error closing JDBC connection: " + e.getMessage() + "</p>");
			}

			out.println("</body></html>");
		}
	}
}
