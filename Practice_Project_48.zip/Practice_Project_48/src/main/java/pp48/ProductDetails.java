package pp48;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>Product Details</title></head><body>");

		Connection connection = DBConnection.getConnection();

		try {

			String sql = "SELECT * FROM PRODUCT";
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultSet = statement.executeQuery();

			out.println("<h3>Product Details:</h3>");
			while (resultSet.next()) {
				out.println("Product ID: " + resultSet.getInt("PID") + "<br>");
				out.println("Product Name: " + resultSet.getString("PNAME") + "<br>");
				out.println("Price: " + resultSet.getInt("PRICE") + "<br><br>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.println("</body></html>");
		}
	}
}
