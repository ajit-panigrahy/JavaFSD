package pp52;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student_Details")
public class Students {
	@Id
	@GeneratedValue
	@Column(name = "SID")
	private int sid;
	@Column(name = "SNAME")
	private String sname;
	@Column(name = "AGE")
	private int age;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Students(String sname, int age) {
		super();
		this.sname = sname;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Students [sid=" + sid + ", sname=" + sname + ", age=" + age + "]";
	}

}
