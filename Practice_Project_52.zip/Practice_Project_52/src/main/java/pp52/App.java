package pp52;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {

		Configuration config = new Configuration();
		config.configure("pp52.cfg.xml").addAnnotatedClass(Students.class);
		SessionFactory sf = config.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();

		Students s1 = new Students("Ajit", 23);
		Students s2 = new Students("Akash", 21);
		Students s3 = new Students("Amit", 28);

		session.save(s1);
		session.save(s2);
		session.save(s3);

		t.commit();

		session.clear();
		sf.close();
	}
}
