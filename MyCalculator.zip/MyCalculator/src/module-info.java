/**
 * 
 */
/**
 * 
 */
module MyCalculator {
}