package PracticeProject19;

//Common interface with a common method
interface Animal {
	void sound();
}

//Interface inheriting from Animal
interface Bird extends Animal {
	void fly();
}

//Interface inheriting from Animal
interface Mammal extends Animal {
	void run();
}

//Concrete class implementing both Bird and Mammal interfaces
class Bat implements Bird, Mammal {
	@Override
	public void sound() {
		System.out.println("Chirp");
	}

	@Override
	public void fly() {
		System.out.println("Bat is flying");
	}

	@Override
	public void run() {
		System.out.println("Bat is running");
	}
}

public class PracticeProject19 {
	public static void main(String[] args) {
		// Create an instance of Bat
		Bat bat = new Bat();

		// Call methods from both interfaces
		bat.sound();
		bat.fly();
		bat.run();
	}
}
