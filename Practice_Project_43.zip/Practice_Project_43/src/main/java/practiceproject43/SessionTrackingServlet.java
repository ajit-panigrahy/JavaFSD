package practiceproject43;
//Write a program to demonstrate Session Tracking using Hidden Form Fields.

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {

	@Override

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		String name = request.getParameter("name");

		if (name != null) {
			session.setAttribute("name", name);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<h2>Hello " + name + ", welcome back to the session!</h2>");
		} else {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<h2>Welcome to the session!</h2>");
			out.println("<form action='SessionTrackingServlet' method='post'>");
			out.println("Enter your name: <input type='text' name='name'>");
			out.println("<input type='hidden' name='sessionId' value='" + session.getId() + "'>");
			out.println("<input type='submit' value='Submit'>");
			out.println("</form>");
		}
	}

	@Override

	protected

			void

			doPost(HttpServletRequest request, HttpServletResponse response)

					throws ServletException, IOException {
		doGet(request, response);
	}
}