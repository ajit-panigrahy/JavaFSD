package PracticeProject34;

import java.util.InputMismatchException;
import java.util.Scanner;

public class InsertionSort {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			System.out.print("Enter size of Array : ");
			int s = sc.nextInt();
			int arr[] = new int[s];
			System.out.println("Enter " + s + " elements");

			for (int i = 0; i < s; i++) {

				System.out.print("Enter " + i + " element : ");
				arr[i] = sc.nextInt();
			}

			System.out.println("Before Sorting ");
			for (int i : arr) {
				System.out.print(i + "\t");
			}

			int[] sortedArray = insertionSort(arr);

			System.out.println("\nAfter Sorting ");
			for (int i : sortedArray) {
				System.out.print(i + "\t");
			}
		} catch (InputMismatchException ex) {
			System.out.println("Ivalid Input Please Enter A Integer Elemet And Try Again");
			return;
		} catch (Exception ex2) {
			System.out.println("Some Unknown Error Occured Please Try Again");
			ex2.printStackTrace();
			return;
		} finally {
			sc.close();
		}
	}

	private static int[] insertionSort(int[] arr) {

		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = 0; j < arr.length - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					int t = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = t;

					for (int k = j; k > 0; k--) {
						if (arr[k] > arr[k - 1]) {
							int t1 = arr[k];
							arr[k] = arr[k - 1];
							arr[k - 1] = t1;
						}
					}
				}
			}
		}

		return arr;
	}
}