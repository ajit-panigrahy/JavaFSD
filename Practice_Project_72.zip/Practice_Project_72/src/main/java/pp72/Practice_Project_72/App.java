package pp72.Practice_Project_72;

public class App {

	public String greet() {
		return "Hello";
	}

}
