package pp72.Practice_Project_72;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AppTest {

	@Test
	public void testGreet() {
		App a = new App();
		Assertions.assertEquals("Hello", a.greet());
		Assertions.assertEquals("Hi", a.greet());
		
	}
}
