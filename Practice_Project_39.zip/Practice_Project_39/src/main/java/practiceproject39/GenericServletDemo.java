package practiceproject39;
//Write a program to demonstrate the concept of Generic Servlets.

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/GenericServletDemo")
public class GenericServletDemo extends GenericServlet {

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>Generic Servlet Example</h2>");
		out.println("This is a response from a Generic Servlet.");
	}
}