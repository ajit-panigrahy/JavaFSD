package PracticeProject21;

public class PracticeProject21 {
	public static void main(String[] args) {
		int[] unsortedList = { 12, 8, 2, 2, 10, 5, 16, 7, 20, 18, 3, 15, 5, 3 };

		int fourthDistinctSmallest = findFourthDistinctSmallestElement(unsortedList);

		System.out.println("The fourth distinct smallest element is: " + fourthDistinctSmallest);
	}

	// Function to find the fourth distinct smallest element in an unsorted list
	private static int findFourthDistinctSmallestElement(int[] arr) {
		if (arr.length < 4) {
			System.out.println("List has less than four elements.");
			return -1;
		}

		int uniqueCount = 0;
		for (int i = 0; i < arr.length; i++) {
			if (!isDuplicated(arr, i)) {
				uniqueCount++;
			}

			if (uniqueCount == 4) {
				return arr[i];
			}
		}

		System.out.println("List has less than four distinct elements.");
		return -1;
	}

	private static boolean isDuplicated(int[] arr, int currentIndex) {
		for (int i = 0; i < currentIndex; i++) {
			if (arr[i] == arr[currentIndex]) {
				return true; // Element is duplicated
			}
		}
		return false; // Element is not duplicated
	}
}
