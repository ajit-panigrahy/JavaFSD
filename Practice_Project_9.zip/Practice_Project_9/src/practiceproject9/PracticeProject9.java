package practiceproject9;
//Writing a program in Java to verify implementation of arrays

import java.util.Scanner;

public class PracticeProject9 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int singleDimensionalSize = scanner.nextInt();
		int[] singleDimensionalArray = new int[singleDimensionalSize];

		System.out.println("Enter values for the single-dimensional array:");
		for (int i = 0; i < singleDimensionalArray.length; i++) {
			System.out.print("Value at index " + i + ": ");
			singleDimensionalArray[i] = scanner.nextInt();
		}

		System.out.println("\nSingle-Dimensional Array:");
		for (int value : singleDimensionalArray) {
			System.out.print(value + " ");
		}
		System.out.println("\n");

		// Multidimensional Array
		System.out.print("Enter the number of rows for the multidimensional array: ");
		int numRows = scanner.nextInt();
		System.out.print("Enter the number of columns for the multidimensional array: ");
		int numCols = scanner.nextInt();

		int[][] multiDimensionalArray = new int[numRows][numCols];
		int counter = 1;

		System.out.println("Enter values for the multidimensional array:");
		for (int row = 0; row < multiDimensionalArray.length; row++) {
			for (int col = 0; col < multiDimensionalArray[row].length; col++) {
				System.out.print("Value at position (" + row + ", " + col + "): ");
				multiDimensionalArray[row][col] = scanner.nextInt();
			}
		}

		System.out.println("\nMultidimensional Array:");
		for (int row = 0; row < multiDimensionalArray.length; row++) {
			for (int col = 0; col < multiDimensionalArray[row].length; col++) {
				System.out.print(multiDimensionalArray[row][col] + " ");
			}
			System.out.println();
		}

		scanner.close();
	}
}
