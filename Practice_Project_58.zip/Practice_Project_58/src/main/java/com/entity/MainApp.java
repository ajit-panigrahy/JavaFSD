package com.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

	public static void main(String[] args) {
		try (SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory()) {
			try (Session session = factory.openSession()) {
				Transaction transaction = session.beginTransaction();

				// Create an employee with an address
				Employee employee = new Employee();
				employee.setName("Ajit Kumar");

				Address address = new Address();
				address.setStreet("Door no-03/183");
				address.setCity("Bhubaneswar");
				address.setZipcode("751001");

				employee.setAddress(address);

				session.persist(employee);

				transaction.commit();

				Employee getEmployee = session.get(Employee.class, employee.getId());
				System.out.println("Employee Name: " + getEmployee.getName());
				System.out.println("Employee Address: " + getEmployee.getAddress().getStreet() + ", "
						+ getEmployee.getAddress().getCity() + ", " + getEmployee.getAddress().getZipcode());
			}
		}
	}
}
