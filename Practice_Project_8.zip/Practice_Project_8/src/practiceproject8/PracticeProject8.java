package practiceproject8;

//Write a program to create strings and display the conversion of string to StringBuffer and StringBuilder.

public class PracticeProject8 {
	public static void main(String[] args) {
		String originalString = "Hello, World!";

		System.out.println("Original String: " + originalString);

		StringBuffer stringBuffer = new StringBuffer(originalString);
		System.out.println("String to StringBuffer: " + stringBuffer);

		StringBuilder stringBuilder = new StringBuilder(originalString);
		System.out.println("String to StringBuilder: " + stringBuilder);
	}
}
