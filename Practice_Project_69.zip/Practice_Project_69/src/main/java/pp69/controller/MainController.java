package pp69.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import pp70.entity.FileUpload;

@Controller
public class MainController {

	@GetMapping("/uploadForm")
	public String showUploadForm(Model model) {
		model.addAttribute("fileUploadFormEntity", new FileUpload());
		return "FileUploadForm";
	}

	@PostMapping("/upload")
	public String handleFileUpload(FileUpload fileUploadFormEntity) {

		MultipartFile file = fileUploadFormEntity.getFile();

		return "redirect:/uploadForm";
	}
}