package pp50;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	private static Connection connection = null;

	public static Connection getConnection() {
		try {
			if (connection == null || connection.isClosed()) {
				Class.forName("com.mysql.cj.jdbc.Driver");
				String URL = "jdbc:mysql://localhost:3306/JDBC";
				String username = "root";
				String password = "Aa@@11@@";
				connection = DriverManager.getConnection(URL, username, password);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
}
