package pp50;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DBOperations")
public class DBOperations extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>DB Operations</title></head><body>");

		Connection connection = DBConnection.getConnection();
		String operation = request.getParameter("operation");

		if (operation != null) {
			switch (operation) {
			case "Create Database":
				createDatabase(connection, out);
				break;
			case "Use Database":
				useDatabase(connection, out);
				break;
			case "Drop Database":
				dropDatabase(connection, out);
				break;
			default:
				out.println("Invalid operation");
			}
		}

		out.println("</body></html>");
	}

	private void createDatabase(Connection connection, PrintWriter out) {
		try {
			Statement statement = connection.createStatement();
			statement.executeUpdate("CREATE DATABASE IF NOT EXISTS PPDB");
			out.println("Database 'PPDB' created successfully.");
		} catch (SQLException e) {
			e.printStackTrace();
			out.println("Error creating database: " + e.getMessage());
		}
	}

	private void useDatabase(Connection connection, PrintWriter out) {
		try {
			Statement statement = connection.createStatement();
			statement.executeUpdate("USE PPDB");
			out.println("Using database 'PPDB'.");
		} catch (SQLException e) {
			e.printStackTrace();
			out.println("Error using database: " + e.getMessage());
		}
	}

	private void dropDatabase(Connection connection, PrintWriter out) {
		try {
			Statement statement = connection.createStatement();
			statement.executeUpdate("DROP DATABASE IF EXISTS PPDB");
			out.println("Database 'PPDB' dropped successfully.");
		} catch (SQLException e) {
			e.printStackTrace();
			out.println("Error dropping database: " + e.getMessage());
		}
	}
}
