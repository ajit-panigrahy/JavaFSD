function first() {
    console.log("Welcome To Javascript");
}
first();

function Employee(id,name,age,sal){
    this.id=id;
    this.name=name;
    this.age=age;
    this.sal=sal;
}

const emp=new Employee(101,"Ajit",23,16540);

console.log(emp);
console.log(typeof(emp.age));
console.log(typeof(emp.id));
console.log(typeof(emp.name));
console.log(typeof(emp.sal));
console.log(typeof(emp));

let emp1=JSON.stringify(emp);

document.getElementById("first").innerHTML="<h1>'"+emp1+"'</h1>";