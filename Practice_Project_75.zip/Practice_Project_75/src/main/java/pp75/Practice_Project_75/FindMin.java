package pp75.Practice_Project_75;

public class FindMin {

	public int minResult(int a[]) {
		int min = a[0];
		for (int i = 1; i < a.length; i++) {
			if (min > a[i])
				min = a[i];
		}
		return min;

	}

}
