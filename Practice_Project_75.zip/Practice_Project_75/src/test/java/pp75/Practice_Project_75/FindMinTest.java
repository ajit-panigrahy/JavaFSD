package pp75.Practice_Project_75;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FindMinTest {

	private final FindMin fm = new FindMin();

	@ParameterizedTest
	@MethodSource("inputs")
	public void minTest(int[] a, int expectedVal) {
		int actual = fm.minResult(a);
		assertEquals(expectedVal, actual);
	}

	static Stream<Arguments> inputs() {
		return Stream.of(Arguments.of(new int[]{10, 20, 30, 40}, 10),
				Arguments.of(new int[]{10, 5, 30, 40}, 5),
				Arguments.of(new int[]{100, 50, 30, 40}, 30),
				Arguments.of(new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9}, 1));
	}
}
