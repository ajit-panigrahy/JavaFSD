package PracticeProject13;
//Write a program in Java to demonstrate synchronization

class T2 implements Runnable {
	synchronized public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("2:- " + i);
		}
	}
}

public class ThreadWithSynchronized {

	public static void main(String[] args) {
		T2 t3 = new T2();

		Thread t = new Thread(t3);
		Thread t1 = new Thread(t3);

		t.start();
		t1.start();

	}

}
