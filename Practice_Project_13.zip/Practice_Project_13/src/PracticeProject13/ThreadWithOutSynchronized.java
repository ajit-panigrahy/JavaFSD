package PracticeProject13;
//Write a program in Java to demonstrate synchronization

class T1 implements Runnable {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("1:- " + i);
		}
	}
}

public class ThreadWithOutSynchronized {

	public static void main(String[] args) {
		T1 t3 = new T1();

		Thread t = new Thread(t3);
		Thread t1 = new Thread(t3);

		t.start();
		t1.start();

	}

}
