package pp53;

import java.util.List;

import pp53.products.Product;

public class MainApp {
	public static void main(String[] args) {
		Eproduct eproduct = new Eproduct();
		List<Product> products = eproduct.listProducts();
		System.out.println("----------------------------------------");
		for (Product p : products) {
			System.out.println(
					"ProductId-> " + p.getPid() + " ProductName-> " + p.getPname() + " ProductPrice-> " + p.getPrice());
		}
	}
}
