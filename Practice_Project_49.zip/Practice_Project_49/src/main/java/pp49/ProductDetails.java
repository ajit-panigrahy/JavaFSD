package pp49;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>Product Details</title></head><body>");

		Connection connection = DBConnection.getConnection();

		try {
			// Call the stored procedure to retrieve product details
			CallableStatement callableStatement = connection.prepareCall("{call GetProductDetails()}");
			ResultSet resultSet = callableStatement.executeQuery();

			out.println("<h3>Product Details:</h3>");
			while (resultSet.next()) {
				out.println("Product ID: " + resultSet.getInt("PID") + "<br>");
				out.println("Product Name: " + resultSet.getString("PNAME") + "<br>");
				out.println("Price: " + resultSet.getInt("PRICE") + "<br><br>");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			out.println("</body></html>");
		}
	}
}
