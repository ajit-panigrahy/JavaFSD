function first() {
    console.log("Welcome To Javascript");
}
first();


function add(){
    const a =parseFloat(document.getElementById("fno").value);
    const b=parseFloat(document.getElementById("sno").value);
    document.getElementById("display").innerHTML="<strong>'"+(a+b).toFixed(2)+"'</strong>";
}
function sub(){
    const a =parseFloat(document.getElementById("fno").value);
    const b=parseFloat(document.getElementById("sno").value);
    document.getElementById("display").innerHTML="<strong>'"+(a-b).toFixed(2)+"'</strong>";
}
function div(){
    const a =parseFloat(document.getElementById("fno").value);
    const b=parseFloat(document.getElementById("sno").value);
    document.getElementById("display").innerHTML="<strong>'"+(a/b).toFixed(2)+"'</strong>";
}
function mul(){
    const a =parseFloat(document.getElementById("fno").value);
    const b=parseFloat(document.getElementById("sno").value);
    document.getElementById("display").innerHTML="<strong>'"+(a*b).toFixed(2)+"'</strong>";
}
