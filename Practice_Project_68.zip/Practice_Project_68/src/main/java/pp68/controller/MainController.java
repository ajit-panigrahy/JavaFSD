package pp68.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import pp68.exception.ProductNotFoundException;

@Controller
public class MainController {

	@GetMapping("/throwException")
	public String throwException() {
		throw new ProductNotFoundException("Product not found");
	}
}
