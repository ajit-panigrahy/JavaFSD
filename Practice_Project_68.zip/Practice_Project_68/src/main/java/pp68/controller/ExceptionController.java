package pp68.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import pp68.exception.ProductNotFoundException;

@ControllerAdvice
@Controller
public class ExceptionController {

	@ExceptionHandler(ProductNotFoundException.class)
	public String handleProductNotFoundException(ProductNotFoundException ex,
			Model model) {
		model.addAttribute("errorMessage", ex.getMessage());
		return "error";
	}
}