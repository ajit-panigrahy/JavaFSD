package pp51;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>Product Details</title></head><body>");

		Connection connection = DBConnection.getConnection();

		String operation = request.getParameter("operation");
		int productID = Integer.parseInt(request.getParameter("productID"));
		String productName = request.getParameter("productName");
		int productPrice = Integer.parseInt(request.getParameter("productPrice"));

		try {
			if (operation.equals("Insert Product")) {
				insertProduct(connection, productName, productPrice);
				out.println("Product inserted successfully.");
			} else if (operation.equals("Update Product")) {
				updateProduct(connection, productID, productName, productPrice);
				out.println("Product updated successfully.");
			} else if (operation.equals("Delete Product")) {
				deleteProduct(connection, productID);
				out.println("Product deleted successfully.");
			} else {
				out.println("Invalid operation.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			out.println("Error performing operation: " + e.getMessage());
		} finally {
			out.println("</body></html>");
		}
	}

	private void insertProduct(Connection connection, String productName, int productPrice) throws SQLException {
		String insertQuery = "INSERT INTO PRODUCT (PNAME, PRICE) VALUES (?, ?)";
		try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
			insertStatement.setString(1, productName);
			insertStatement.setInt(2, productPrice);
			insertStatement.executeUpdate();
		}
	}

	private void updateProduct(Connection connection, int productID, String productName, int productPrice)
			throws SQLException {
		String updateQuery = "UPDATE PRODUCT SET PNAME=? , PRICE=? WHERE PID=?";
		try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
			updateStatement.setString(1, productName);
			updateStatement.setInt(2, productPrice);
			updateStatement.setInt(3, productID);
			updateStatement.executeUpdate();
		}

	}

	private void deleteProduct(Connection connection, int productID) throws SQLException {
		String deleteQuery = "DELETE FROM PRODUCT WHERE PID=?";
		try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
			deleteStatement.setInt(1, productID);
			deleteStatement.executeUpdate();
		}
	}
}
