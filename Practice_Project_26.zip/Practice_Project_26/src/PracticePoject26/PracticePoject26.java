package PracticePoject26;

class Node {
	int data;
	Node next;
	Node prev;

	public Node(int data) {
		this.data = data;
		this.next = null;
		this.prev = null;
	}
}

class DoublyLinkedList {
	Node head;

	// Function to insert a new node at the end of the doubly linked list
	public void insert(int data) {
		Node newNode = new Node(data);

		if (head == null) {
			head = newNode;
		} else {
			Node current = head;
			while (current.next != null) {
				current = current.next;
			}
			current.next = newNode;
			newNode.prev = current;
		}
	}

	// Function to traverse the doubly linked list in the forward direction
	public void traverseForward() {
		System.out.println("Doubly Linked List (Forward):");
		Node current = head;
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println();
	}

	// Function to traverse the doubly linked list in the backward direction
	public void traverseBackward() {
		System.out.println("Doubly Linked List (Backward):");
		Node current = head;

		// Move to the end of the list
		while (current != null && current.next != null) {
			current = current.next;
		}

		// Traverse backward
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.prev;
		}

		System.out.println();
	}
}

public class PracticePoject26 {
	public static void main(String[] args) {
		DoublyLinkedList doublyList = new DoublyLinkedList();

		// Insert elements into the doubly linked list
		doublyList.insert(10);
		doublyList.insert(20);
		doublyList.insert(30);
		doublyList.insert(40);
		doublyList.insert(50);

		// Traverse the doubly linked list in the forward direction
		doublyList.traverseForward();

		// Traverse the doubly linked list in the backward direction
		doublyList.traverseBackward();
	}
}
