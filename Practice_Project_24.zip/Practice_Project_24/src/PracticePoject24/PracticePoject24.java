package PracticePoject24;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class PracticePoject24 {
	public static void main(String[] args) {
		List<Integer> linkedList = new LinkedList<>();

		// Insert elements into the linked list
		linkedList.add(1);
		linkedList.add(2);
		linkedList.add(3);
		linkedList.add(3);
		linkedList.add(4);
		linkedList.add(4);
		linkedList.add(4);
		linkedList.add(5);

		System.out.println("Original Linked List:");
		displayLinkedList(linkedList);

		// Delete the first occurrence of a key
		int keyToDelete = 3;
		deleteFirstOccurrence(linkedList, keyToDelete);

		System.out.println("Linked List after deleting first occurrence of " + keyToDelete + ":");
		displayLinkedList(linkedList);
	}

	// Function to delete the first occurrence of a key in the linked list
	private static void deleteFirstOccurrence(List<Integer> list, int key) {
		ListIterator<Integer> iterator = list.listIterator();

		while (iterator.hasNext()) {
			if (iterator.next() == key) {
				iterator.remove();
				return;
			}
		}

		System.out.println("Key not found in the linked list.");
	}

	// Function to display the linked list
	private static void displayLinkedList(List<Integer> list) {
		for (Integer element : list) {
			System.out.print(element + " ");
		}
		System.out.println();
	}
}
