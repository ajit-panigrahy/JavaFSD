package com.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class MainApp {

	public static void main(String[] args) {
		try (SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory()) {
			try (Session session = factory.openSession()) {
				Transaction transaction = session.beginTransaction();

				Author author = new Author();
				author.setName("Ajit");

				Book book1 = new Book();
				book1.setTitle("Java");
				book1.setAuthor(author);

				Book book2 = new Book();
				book2.setTitle("C#");
				book2.setAuthor(author);

				session.persist(author);
				session.persist(book1);
				session.persist(book2);

				transaction.commit();

				session.clear();
				Author loadedAuthor = session.get(Author.class, author.getId());
				List<Book> books = loadedAuthor.getBooks();
				System.out.println("------------------------------------------------");

				System.out.println("Author: " + loadedAuthor.getName());
				System.out.println("Books Count: " + books.size());

				for (Book book : books) {
					System.out.println("Book Title: " + book.getTitle());
				}
			}
		}
	}
}
