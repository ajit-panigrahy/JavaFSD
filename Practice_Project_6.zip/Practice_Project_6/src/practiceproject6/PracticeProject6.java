package practiceproject6;

//Writing a program in Java to verify implementations of maps

import java.util.HashMap;
import java.util.Map;

public class PracticeProject6 {

	public static void main(String[] args) {

		Map<String, Integer> studentScores = new HashMap<>();

		studentScores.put("Alice", 95);
		studentScores.put("Bob", 82);
		studentScores.put("Charlie", 90);
		studentScores.put("David", 78);

		System.out.println("Bob's Score: " + studentScores.get("Bob"));
		System.out.println();

		System.out.println("Student Scores:");
		for (String name : studentScores.keySet()) {
			int score = studentScores.get(name);
			System.out.println(name + ": " + score);
		}
		System.out.println();

		String studentName = "Alice";
		if (studentScores.containsKey(studentName)) {
			System.out.println(studentName + " is in the map.");
		} else {
			System.out.println(studentName + " is not in the map.");
		}
		System.out.println();

		String studentToRemove = "Charlie";
		studentScores.remove(studentToRemove);
		System.out.println(studentToRemove + "'s score removed.");

		System.out.println("\nUpdated Student Scores:");
		for (Map.Entry<String, Integer> entry : studentScores.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue());
		}
	}
}
