//Writing a program in Java to implement implicit and explicit type casting
public class PracticeProject_1 {
	public static void main(String[] args) {
		// Implicit casting
		int intValue = 10;
		double doubleValue = intValue; // Automatically converts int to double
		System.out.println("Implicit Casting :");
		System.out.println("int value: " + intValue);
		System.out.println("double value: " + doubleValue);
		System.out.println();

		// Explicit casting
		double anotherDoubleValue = 15.75;
		int anotherIntValue = (int) anotherDoubleValue; // Manually converts double to int
		System.out.println("Explicit Casting :");
		System.out.println("double value: " + anotherDoubleValue);
		System.out.println("int value: " + anotherIntValue);
	}
}
