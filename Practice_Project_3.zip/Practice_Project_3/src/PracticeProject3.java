
//Writing a program in Java to verify implementations of methods and ways of calling a method 

public class PracticeProject3 {

	// Method with no parameters and no return value
	public static void simpleMethod() {
		System.out.println("This is a simple method with no parameters and no return value.");
	}

	// Method with parameters and a return value
	public static int add(int a, int b) {
		return a + b;
	}

	// Method with default access modifier
	static void defaultAccessMethod() {
		System.out.println("This is a method with default access modifier.");
	}

	// Private method
	private static void privateMethod() {
		System.out.println("This is a private method.");
	}

	public static void main(String[] args) {
		// Calling a method with no parameters and no return value
		simpleMethod();

		// Calling a method with parameters and a return value
		int result = add(5, 3);
		System.out.println("Result of addition: " + result);

		// Calling a method with default access modifier
		defaultAccessMethod();

		// Calling a private method within the same class
		privateMethod();

		// Creating an object to call an instance method
		PracticeProject3 example = new PracticeProject3();
		example.instanceMethod();
	}

	// Instance method
	public void instanceMethod() {
		System.out.println("This is an instance method.");
	}
}
