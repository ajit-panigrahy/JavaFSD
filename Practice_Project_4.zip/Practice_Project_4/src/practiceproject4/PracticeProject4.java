package practiceproject4;

//Writing a program in Java to verify the implementations of constructor types

public class PracticeProject4 {

	// Default constructor
	public PracticeProject4() {
		System.out.println("Default Constructor: This is a default constructor.");
	}

	// Parameterized constructor
	public PracticeProject4(int value) {
		System.out.println("Parameterized Constructor: Value passed to constructor is " + value);
	}

	// calling one constructor from another
	public PracticeProject4(String message, int value) {
		this(value); // Call the parameterized constructor
		System.out.println("Constructor Chaining: " + message);
	}

	public static void main(String[] args) {
		// Creating an object using the default constructor
		new PracticeProject4();

		// Creating an object using the parameterized constructor
		new PracticeProject4(42);

		// Creating an object using constructor chaining
		new PracticeProject4("Hello", 99);
	}
}
