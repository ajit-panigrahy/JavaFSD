package practiceroject37;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

//Write a program to demonstrate the differences between GET and POST using Servlet.

@WebServlet("/GetPostServlet")
public class GetPostServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>GET Method</h2>");
		out.println("Hello " + name + ", you used GET method.");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>POST Method</h2>");
		out.println("Hello " + name + ", you used POST method.");
	}
}